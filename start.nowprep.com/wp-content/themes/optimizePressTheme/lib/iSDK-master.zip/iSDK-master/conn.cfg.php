<?php
$connInfo = array(
    "appname:appname:i:InfusionsoftAPIkey:This is for appname.infusionsoft.com"
);